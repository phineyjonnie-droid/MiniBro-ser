# MiniBrowser v0.6

Features added in v0.6:
- Theme switching: light/dark/system/auto (automatic by time with hourly check)
- Swipe-to-refresh: pull down to reload current page
- Data Saver mode: disable images, block videos and large media heuristically, inject JS to stop autoplay
- Settings UI updated for theme and data saver toggles

How to use:
- Open project in Android Studio. Build and run (or generate APK with ./gradlew assembleDebug).
- In Settings, set Theme to 'auto' for automatic day/night switching (06:00-17:59 light, 18:00-05:59 dark).
- Enable Data Saver to reduce image/video loading.

Security & notes:
- This is a prototype. Data Saver heuristics are simple and may need refinement for false positives.
- Theme auto-check uses WorkManager to re-evaluate hourly.

